<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Project extends Model
{
    protected $guarded = [];

    public function skills()
    {
        return $this->belongsToMany(Skill::class);
    }
}
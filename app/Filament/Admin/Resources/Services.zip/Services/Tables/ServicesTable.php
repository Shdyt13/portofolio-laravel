<?php

namespace App\Filament\Admin\Resources\Services\Tables;

use Filament\Tables\Table;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Columns\ToggleColumn;
// Menggunakan namespace Actions yang benar untuk versi Filament Anda
use Filament\Actions\EditAction;
use Filament\Actions\DeleteAction;

class ServicesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label('Nama Layanan')
                    ->searchable()
                    ->sortable(),
                
                TextColumn::make('fee')
                    ->label('Tarif')
                    ->searchable(),

                ToggleColumn::make('is_visible')
                    ->label('Status (Tampil)'),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
                DeleteAction::make(),
            ]);
    }
}